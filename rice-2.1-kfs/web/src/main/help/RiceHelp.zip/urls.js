var g_ContentsURL = "Rice%20Help-toc.htm";
var g_IndexURL = "Rice%20Help-index.htm";
var g_SearchURL = "Rice%20Help-search.htm";
var g_FavoritesURL = "Rice%20Help-favorites.htm";
