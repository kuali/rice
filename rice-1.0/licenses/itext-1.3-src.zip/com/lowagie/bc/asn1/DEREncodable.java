package com.lowagie.bc.asn1;

public interface DEREncodable
{
    public DERObject getDERObject();
}
